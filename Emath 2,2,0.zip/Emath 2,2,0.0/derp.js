// JavaScript Document
window.onload=function(){
	logo1=document.getElementById("logo1");
	logo2=document.getElementById("logo2");
	inte1=document.getElementById("inte1");
	inte2=document.getElementById("inte2");
	frac1=document.getElementById("frac1");
	frac2=document.getElementById("frac2");
	dec1=document.getElementById("dec1");
	dec2=document.getElementById("dec2");
	prec1=document.getElementById("perc1");
	prec2=document.getElementById("perc2");
	ratio1=document.getElementById("ratio1");
	ratio2=document.getElementById("ratio2");
	sf1=document.getElementById("sf1");
	sf2=document.getElementById("sf2");
	rect1=document.getElementById("rect1");
	rect2=document.getElementById("rect2");
	squ1=document.getElementById("squ1");
	squ2=document.getElementById("squ2");
	par1=document.getElementById("par1");
	par2=document.getElementById("par2");
	rho1=document.getElementById("rho1");
	rho2=document.getElementById("rho2");
	tri1=document.getElementById("tri1");
	tri2=document.getElementById("tri2");
	pyth1=document.getElementById("pyth1");
	pyth2=document.getElementById("pyth2");
	trig1=document.getElementById("trig1");
	trig2=document.getElementById("trig2");
	cir2=document.getElementById("cir2");
	cir2=document.getElementById("cir2");
	trap1=document.getElementById("trap1");
	trap2=document.getElementById("trap2");
	poly1=document.getElementById("poly1");
	poly2=document.getElementById("poly2");
	hex1=document.getElementById("hex1");
	hex2=document.getElementById("hex2");
	hep1=document.getElementById("hep1");
	hep2=document.getElementById("hep2");
	octa1=document.getElementById("octa1");
	octa2=document.getElementById("octa2");
	lin1=document.getElementById("lin1");
	lin2=document.getElementById("lin2");
	qua1=document.getElementById("qua1");
	qua2=document.getElementById("qua2");
	equ1=document.getElementById("equ1");
	equ2=document.getElementById("equ2");
	inv1=document.getElementById("inv1");
	inv2=document.getElementById("inv2");
	add1=document.getElementById("add1");
	add2=document.getElementById("add2");
	mul1=document.getElementById("mul1");
	mul2=document.getElementById("mul2");
	sim1=document.getElementById("sim1");
	sim2=document.getElementById("sim2");
	fac1=document.getElementById("fac1");
	fac2=document.getElementById("fac2");
	law1=document.getElementById("law1");
	law2=document.getElementById("law2");
	neg1=document.getElementById("neg1");
	neg2=document.getElementById("neg2");
	fra1=document.getElementById("fra1");
	fra2=document.getElementById("fra2");
	sci1=document.getElementById("sci1");
	sci2=document.getElementById("sci2");
	sur1=document.getElementById("sur1");
	sur2=document.getElementById("sur2");
				
				logo1.onmouseover=function(){
					logo1.width='0';
					logo2.width='60';
				};
				
				logo2.onmouseout=function(){
					logo1.width='60';
					logo2.width='0';
				};
				
				inte1.onmouseover=function(){
					inte1.height='0';
					inte2.height='30';
				};
				
				inte2.onmouseout=function(){
					inte1.height='30';
					inte2.height='0';
				};
				
				frac1.onmouseover=function(){
					frac1.height='0';
					frac2.height='30';
				};
				
				frac2.onmouseout=function(){
					frac1.height='30';
					frac2.height='0';
				};
				
				dec1.onmouseover=function(){
					dec1.height='0';
					dec2.height='30';
				};
				
				dec2.onmouseout=function(){
					dec1.height='30';
					dec2.height='0';
				};
				
				prec1.onmouseover=function(){
					prec1.height='0';
					prec2.height='30';
				};
				
				prec2.onmouseout=function(){
					prec1.height='30';
					prec2.height='0';
				};
				
				ratio1.onmouseover=function(){
					ratio1.height='0';
					ratio2.height='30';
				};
				
				ratio2.onmouseout=function(){
					ratio1.height='30';
					ratio2.height='0';
				};
				
				sf1.onmouseover=function(){
					sf1.height='0';
					sf2.height='30';
				};
				
				sf2.onmouseout=function(){
					sf1.height='30';
					sf2.height='0';
				};
				
				rect1.onmouseover=function(){
					rect1.height='0';
					rect2.height='30';
				};
				
				rect2.onmouseout=function(){
					rect1.height='30';
					rect2.height='0';
				};
				
				squ1.onmouseover=function(){
					squ1.height='0';
					squ2.height='30';
				};
				
				squ2.onmouseout=function(){
					squ1.height='30';
					squ2.height='0';
				};
				
				par1.onmouseover=function(){
					par1.height='0';
					par2.height='30';
				};
				
				par2.onmouseout=function(){
					par1.height='30';
					par2.height='0';
				};
				
				rho1.onmouseover=function(){
					rho1.height='0';
					rho2.height='30';
				};
				
				rho2.onmouseout=function(){
					rho1.height='30';
					rho2.height='0';
				};
				
				tri1.onmouseover=function(){
					tri1.height='0';
					tri2.height='30';
				};
				
				tri2.onmouseout=function(){
					tri1.height='30';
					tri2.height='0';
				};
				
				pyth1.onmouseover=function(){
					pyth1.height='0';
					pyth2.height='30';
				};
				
				pyth2.onmouseout=function(){
					pyth1.height='30';
					pyth2.height='0';
				};
				
				trig1.onmouseover=function(){
					trig1.height='0';
					trig2.height='30';
				};
				
				trig2.onmouseout=function(){
					trig1.height='30';
					trig2.height='0';
				};
				
				cir1.onmouseover=function(){
					cir1.height='0';
					cir2.height='30';
				};
				
				cir2.onmouseout=function(){
					cir1.height='30';
					cir2.height='0';
				};
				
				trap1.onmouseover=function(){
					trap1.height='0';
					trap2.height='30';
				};
				
				trap2.onmouseout=function(){
					trap1.height='30';
					trap2.height='0';
				};
				
				poly1.onmouseover=function(){
					poly1.height='0';
					poly2.height='30';
				};
				
				poly2.onmouseout=function(){
					poly1.height='30';
					poly2.height='0';
				};
				
				hex1.onmouseover=function(){
					hex1.height='0';
					hex2.height='30';
				};
				
				hex2.onmouseout=function(){
					hex1.height='30';
					hex2.height='0';
				};
				
				hep1.onmouseover=function(){
					hep1.height='0';
					hep2.height='30';
				};
				
				hep2.onmouseout=function(){
					hep1.height='30';
					hep2.height='0';
				};
				
				octa1.onmouseover=function(){
					octa1.height='0';
					octa2.height='30';
				};
				
				octa2.onmouseout=function(){
					octa1.height='30';
					octa2.height='0';
				};
				
				lin1.onmouseover=function(){
					lin1.height='0';
					lin2.height='30';
				};
				
				lin2.onmouseout=function(){
					lin1.height='30';
					lin2.height='0';
				};
				
				qua1.onmouseover=function(){
					qua1.height='0';
					qua2.height='30';
				};
				
				qua2.onmouseout=function(){
					qua1.height='30';
					qua2.height='0';
				};
				
				equ1.onmouseover=function(){
					equ1.height='0';
					equ2.height='30';
				};
				
				equ2.onmouseout=function(){
					equ1.height='30';
					equ2.height='0';
				};
				
				inv1.onmouseover=function(){
					inv1.height='0';
					inv2.height='30';
				};
				
				inv2.onmouseout=function(){
					inv1.height='30';
					inv2.height='0';
				};
				
				add1.onmouseover=function(){
					add1.height='0';
					add2.height='30';
				};
				
				add2.onmouseout=function(){
					add1.height='30';
					add2.height='0';
				};
				
				mul1.onmouseover=function(){
					mul1.height='0';
					mul2.height='30';
				};
				
				mul2.onmouseout=function(){
					mul1.height='30';
					mul2.height='0';
				};
				
				sim1.onmouseover=function(){
					sim1.height='0';
					sim2.height='30';
				};
				
				sim2.onmouseout=function(){
					sim1.height='30';
					sim2.height='0';
				};
				
				fac1.onmouseover=function(){
					fac1.height='0';
					fac2.height='30';
				};
				
				fac2.onmouseout=function(){
					fac1.height='30';
					fac2.height='0';
				};
				
				law1.onmouseover=function(){
					law1.height='0';
					law2.height='30';
				};
				
				law2.onmouseout=function(){
					law1.height='30';
					law2.height='0';
				};
				
				neg1.onmouseover=function(){
					neg1.height='0';
					neg2.height='30';
				};
				
				neg2.onmouseout=function(){
					neg1.height='30';
					neg2.height='0';
				};
				
				fra1.onmouseover=function(){
					fra1.height='0';
					fra2.height='30';
				};
				
				fra2.onmouseout=function(){
					fra1.height='30';
					fra2.height='0';
				};
				
				sci1.onmouseover=function(){
					sci1.height='0';
					sci2.height='30';
				};
				
				sci2.onmouseout=function(){
					sci1.height='30';
					sci2.height='0';
				};
				
				sur1.onmouseover=function(){
					sur1.height='0';
					sur2.height='30';
				};
				
				sur2.onmouseout=function(){
					sur1.height='30';
					sur2.height='0';
				};
			};